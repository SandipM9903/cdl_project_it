import React, { useEffect, useState } from 'react';
import DataTable from 'react-data-table-component';
import { IoEnterOutline } from 'react-icons/io5';
import { CgCloseO } from 'react-icons/cg';
import { IoIosArrowDropup, IoIosArrowDropdown } from "react-icons/io";
import { IoClose } from 'react-icons/io5';
import axios from 'axios';
import { useStore3 } from './ClaimStore';
import { useNavigate } from 'react-router-dom';



const ManagerApproval = ({ rowData, onClose }) => {
  const [rowDataInfo, setRowDataInfo] = useState([]);
  const [cols, setCols] = useState([]);
  const { reimbursementRecord, setReimbursementRecord } = useStore3();
  const [wfLevelActions, setWfLevelActions] = useState([]);
  const [selectedAction, setSelectedAction] = useState(null);
  //const [selectedOptions, setSelectedOptions] = useState({});
  const [actorRemark, setActorRemark] = useState(null);
  const [popupVisible, setPopupVisible] = useState(false);
  const navigate = useNavigate();
  const [showMore, setShowMore] = useState(false);

  const [fetchComments, setfetchComments] = useState([]);
  const [comment, setComment] = useState('');

  const comments = rowData?.empComments ? rowData.empComments.split(',') : [];
  const commentDates = rowData?.empCommentDateTime ? rowData.empCommentDateTime.split(',') : [];

  //const empId = sessionStorage.getItem("UserId");
  const empId = 2;

  const ReadOnlyInputCell = ({ value }) => (
    <input
      type="text"
      value={value}
      readOnly
      className="border border-gray-300  text-gray-700  w-full h-8 p-1"
    />
  );

  useEffect(() => {
    if (rowData) {
      setRowDataInfo([rowData]);

      let columns = [];
      if (rowData.claimType === "ConveyanceClaimWF") {
        columns = [
          { name: <span className="text-base font-semibold">S.No</span>, selector: row => 1 },
          { name: <span className="text-base font-semibold">Date</span>, selector: row => <ReadOnlyInputCell value={row.date} /> },
          { name: <span className="text-base font-semibold">From Location</span>, selector: row => <ReadOnlyInputCell value={row.fromLocation} /> },
          { name: <span className="text-base font-semibold">To Location</span>, selector: row => <ReadOnlyInputCell value={row.toLocation} /> },
          { name: <span className="text-base font-semibold">From Time</span>, selector: row => <ReadOnlyInputCell value={row.fromTime} /> },
          { name: <span className="text-base font-semibold">To Time</span>, selector: row => <ReadOnlyInputCell value={row.toTime} /> },
          { name: <span className="text-base font-semibold">Purpose</span>, selector: row => <ReadOnlyInputCell value={row.purpose} /> },
          { name: <span className="text-base font-semibold">Mode</span>, selector: row => <ReadOnlyInputCell value={row.expMode} /> },
          { name: <span className="text-base font-semibold">KM</span>, selector: row => <ReadOnlyInputCell value={row.distance} /> },
          { name: <span className="text-base font-semibold">Currency</span>, selector: row => <ReadOnlyInputCell value={row.currency} /> },
          { name: <span className="text-base font-semibold">Amount</span>, selector: row => <ReadOnlyInputCell value={row.amount} /> },
          { name: <span className="text-base font-semibold">Documents</span>, selector: row => row.documents },
        ];
      } else if (rowData.claimType === "TravelClaimWF") {
        columns = [
          { name: "S.No", selector: row => 1 },
          // { name: "Date", selector: row => <ReadOnlyInputCell value={row.date} /> },
          { name: "Exp Mode", selector: row => <ReadOnlyInputCell value={row.expMode} /> },
          { name: "From Location", selector: row => <ReadOnlyInputCell value={row.fromLocation} /> },
          { name: "To Location", selector: row => <ReadOnlyInputCell value={row.toLocation} /> },
          { name: "Currency", selector: row => <ReadOnlyInputCell value={row.currency} /> },
          { name: "Amount", selector: row => <ReadOnlyInputCell value={row.amount} /> },
          { name: "Documents", selector: row => row.documents },
        ];
      } else if (rowData.claimType === "FoodClaimWF") {
        columns = [
          { name: "S.No", selector: row => 1 },
          { name: "Date", selector: row => <ReadOnlyInputCell value={row.date} /> },
          { name: "Purpose", selector: row => <ReadOnlyInputCell value={row.purpose} /> },
          { name: "Currency", selector: row => <ReadOnlyInputCell value={row.currency} /> },
          { name: "Amount", selector: row => <ReadOnlyInputCell value={row.amount} /> },
          { name: "Documents", selector: row => row.documents },
        ];
      } else if (rowData.claimType === "MobileClaimWF") {
        columns = [
          { name: "S.No", selector: row => 1 },
          { name: "Date", selector: row => <ReadOnlyInputCell value={row.date} /> },
          { name: "Purpose", selector: row => <ReadOnlyInputCell value={row.purpose} /> },
          { name: "Currency", selector: row => <ReadOnlyInputCell value={row.currency} /> },
          { name: "Amount", selector: row => <ReadOnlyInputCell value={row.amount} /> },
          { name: "Documents", selector: row => row.documents },
        ];
      } else if (rowData.claimType === "MiscellaneousClaimWF") {
        columns = [
          { name: "S.No", selector: row => 1 },
          { name: "Date", selector: row => <ReadOnlyInputCell value={row.date} /> },
          { name: "Exp Mode", selector: row => <ReadOnlyInputCell value={row.expMode} /> },
          { name: "Purpose", selector: row => <ReadOnlyInputCell value={row.purpose} /> },
          { name: "Currency", selector: row => <ReadOnlyInputCell value={row.currency} /> },
          { name: "Amount", selector: row => <ReadOnlyInputCell value={row.amount} /> },
          { name: "Documents", selector: row => row.documents },
        ];
      }
      setCols(columns);
    }
  }, [rowData]);


  useEffect(() => {
    if (rowData) {
      const fetchActions = async () => {
        try {
          // const response = await axios.get(`/api/wflevelactions?seqId=${rowData.wfSeqId}`);
          const response = await axios.get(`http://localhost:9001/api/workflow/getWfLevelActions/${rowData.claimNum}/${empId}`)
          setWfLevelActions(response.data);
        } catch (error) {
          console.error("Error fetching workflow level actions", error);
        }
      };
      fetchActions();
    }
  }, [rowData]);

  const handleActionClick = (action) => {
    setSelectedAction(action);
    setPopupVisible(true);
  };

  const handleActionConfirmation = async () => {
    try {
      const url = `http://localhost:9001/api/workflow/getActions/${rowData.claimNum}/${empId}/${actorRemark}?selectedOption=${selectedAction}`;
      const response = await axios.get(url);

      // Display the success message from the response
      alert(`Manager has been ${response.data}`);

      //navigate('/approvals/:requestType');
      setPopupVisible(false);
      navigate(-1);
    } catch (error) {
      console.error("Error handling action confirmation", error);
      alert("An error occurred while processing your request. Please try again.");
    }
  };


  const handleClosePopup = () => {
    setPopupVisible(false);
  };

  const submitMgrComment = () => {

    if (comment.trim() === '') {

      alert('Comment cannot be empty');

      // setShouldPost(false);

      return;

    }

    const postData = {

      empId: rowData.empId,

      claimType: rowData.claimType,

      claimNum: rowData.claimNum,

      mgrComments: comment,

    };

    const apiEndpoints = {

      ConveyanceClaimWF: 'http://localhost:9001/api/claims/conveyance/mgrComments',

      TravelClaimWF: 'http://localhost:9001/api/claims/travel/mgrComments',

      MobileClaimWF: 'http://localhost:9001/api/claims/mobile/mgrComments',

      FoodClaimWF: 'http://localhost:9001/api/claims/foodItem/mgrComments',

      MiscellaneousClaimWF: 'http://localhost:9001/api/claims/miscellaneous/mgrComments'

    };

    const claimType = rowData.claimType;

    const url = apiEndpoints[claimType];

    if (url) {

      axios.post(url, postData)

        .then(response => {

          console.log(`Comment posted successfully to ${url}:`, response.data);

          setComment('');

          fetchMgrComment();

          

        })

        .catch(error => {

          console.error(`Error posting comment to ${url}:`, error);

        })

        .finally(() => {

          // setShouldPost(false);

        });

    } else {

      console.error('Invalid expense type:', claimType);

      // setShouldPost(false);

    }



  }





  const [mgrComments, setMgrComments] = useState([]);

  const [error, setError] = useState(null);



  const fetchMgrComment = () => {

    const { empId, claimType, claimNum } = rowData;



    const apiEndpoints = {

      TravelClaimWF: `http://localhost:9001/api/claims/getTravelMgrComments/${empId}/${claimType}/${claimNum}`,

      FoodClaimWF: `http://localhost:9001/api/claims/getFoodMgrComments/${empId}/${claimType}/${claimNum}`,

      MobileClaimWF: `http://localhost:9001/api/claims/getMobileMgrComments/${empId}/${claimType}/${claimNum}`,

      ConveyanceClaimWF: `http://localhost:9001/api/claims/getConveyanceMgrComments/${empId}/${claimType}/${claimNum}`,

      MiscellaneousClaimWF: `http://localhost:9001/api/claims/getMiscellaneousMgrComments/${empId}/${claimType}/${claimNum}`,

    };



    const url = apiEndpoints[claimType];



    if (url) {

      axios.get(url)

        .then(response => {

          setMgrComments(response.data);

        })

        .catch(error => {

          console.error('Error fetching comments:', error);

          setError('Error fetching comments');

        });

    } else {

      console.error('Invalid expense type:', claimType);

      setError('Invalid expense type');

    }

  };



  useEffect(() => {

    fetchMgrComment();

  }, [rowData]);

  return (
    <div className=''>
      <div className="fixed inset-0 flex items-center justify-center bg-gray-800 bg-opacity-50 p-4">
        <div className="bg-white md:p-8 p-3 rounded-lg h-full md:w-full w-[412px] flex flex-col overflow-y-auto">
          <div className='flex justify-between items-center'>
            <h1 className='text-2xl font-semibold'>Request No :</h1>
            <button onClick={onClose}><CgCloseO className='text-red-600 text-xl' /></button>
          </div>
          <div className='pt-2'>
            <div className='border border-gray-300 shadow-md p-2'>
              <div className='grid grid-cols-12 gap-4'>
                <div className='col-span-5'>
                  <div className='grid grid-cols-5 border-b-[1px] border-gray-200 p-3'>
                    <div className='col-span-2 text-gray-500 font-medium '>Request Number</div>
                    <div className='col-span-3 font-medium text-gray-700 ml-5'>{rowData.claimNum}</div>
                  </div>
                  <div className='grid grid-cols-5 border-b-[1px] border-gray-200 p-3'>
                    <div className='col-span-2 text-gray-500 font-medium '>Employee Name</div>
                    <div className='col-span-3 font-medium text-gray-700 ml-5'>{rowData.empResDTO.firstName}</div>
                  </div>
                  <div className='grid grid-cols-5 border-b-[1px] border-gray-200 p-3'>
                    <div className='col-span-2 text-gray-500 font-medium'>Email</div>
                    <div className='col-span-3 font-medium text-gray-700 ml-5'>{rowData.empResDTO.emailId}</div>
                  </div>
                  <div className='grid grid-cols-5 border-b-[1px] border-gray-200 p-3'>
                    <div className='col-span-2 text-gray-500 font-medium'>Employee Code</div>
                    <div className='col-span-3 font-medium text-gray-700 ml-5'>{rowData.empId}</div>
                  </div>
                  <div className='grid grid-cols-5 border-b-[1px] border-gray-200 p-3'>
                    <div className='col-span-2 text-gray-500 font-medium'>Reporting manager</div>
                    <div className='col-span-3 font-medium text-gray-700 ml-5'>{rowData.empResDTO.reportingManager}</div>
                  </div>
                  <div className='grid grid-cols-5 border-b-[1px] border-gray-200 p-3'>
                    <div className='col-span-2 text-gray-500 font-medium'>Mobile Number</div>
                    <div className='col-span-3 font-medium text-gray-700 ml-5'>{rowData.empResDTO.primaryContactNo}</div>
                  </div>
                  <div className='flex md:space-x-36 space-x-[70px] p-3 mt-3 md:text-base text-sm'>
                    <div className='font-medium text-gray-700'>WBS</div>
                    <div className='ml-5'>{rowData.wbsId}</div>
                  </div>
                  <div className='p-3'>
                    <h4 className='md:my-2 my-4 md:text-sm text-xs'>Choose Expense Type to Continue</h4>
                    <div className='flex md:space-x-20 space-x-2 md:text-base text-sm'>
                      <h3 className='font-medium text-gray-700'>Expense Type</h3>
                      <select className='ml-5 border border-gray-300' disabled>
                        <option>{rowData.claimType}</option>
                      </select>
                    </div>
                  </div>
                  <div className='flex md:space-x-24 space-x-6 p-3 md:text-base text-sm'>
                    <h3>Description</h3>
                    <input type="text" id="desc" className='h-[80px] w-[380px] border border-gray-300' value={rowData.description} />
                  </div>
                </div>
                <div className='col-span-3 text-center'>
                  <div className='flex text-xl font-semibold ml-24'>
                    <h2>Status : </h2>
                    <h2 className='text-red-500 ml-2'>Pending</h2>
                  </div>
                  <div className='border border-gray-300 shadow-lg w-60 h-[154px] text-center p-4 mt-32 ml-8'>
                    <h1 className='mt-7 font-medium'>Total Claim Amount</h1>
                    <div className='text-red-500 mt-2 text-xl'>
                      INR {rowData.amount}
                    </div>
                  </div>
                </div>
                <div className='col-span-4'>
                  <h2 className='mb-10 text-xl font-semibold text-center'>Application History</h2>
                  <div className='border-l-[2px] border-gray-300'>
                    <div className='justify-between items-center p-4'>
                      <h2 className='text-lg font-medium text-red-500'>Pending</h2>
                      <div className='flex'>
                        <div className='text-gray-400 font-medium mr-2'>With</div>
                        <div className='text-gray-700 font-medium'>Manager</div>
                      </div>
                    </div>

                    <div>mgr comments:</div>

{mgrComments.length > 0 ? (

  mgrComments.map((comment, index) => (

    <div key={index}>

      {comment.split('\n').map((line, i) => (

        <div key={i}>{line}</div>

      ))}

    </div>

  ))

) : (

  <p>No comments found</p>

)}
                    <div className='flex mt-3 p-4'>
                      <input
                        className='border border-gray-300 w-full text-sm p-2'
                        placeholder='Enter your text...' value={comment}

                        onChange={(e) => setComment(e.target.value)}
                      />
                       <IoEnterOutline onClick={submitMgrComment} className='ml-[-2rem] mt-1 text-xl cursor-pointer'/>
                    </div>
                    <div className='mt-3 p-4'>
                      <div>Comments:</div>
                      {comments.length > 0 ? comments.map((comment, index) => (
                        <div key={index} style={{ marginBottom: '10px' }}>
                          <div>{comment}</div>
                          <div style={{ fontSize: '0.9em', color: 'gray' }}>{commentDates[index]}</div>
                        </div>
                      )) : (
                        <div>No comments available</div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className='pt-4'>
              <h2 className='text-xl font-semibold'>Claim Details</h2>
              <DataTable data={rowDataInfo} columns={cols} className='border border-gray-300 shadow-md mt-2' />
              {/* <div className='flex flex-wrap gap-2 mt-4'>
                {wfLevelActions && wfLevelActions.map((action, index) => (
                  <button
                    key={index}
                    className='bg-blue-500 text-white py-2 px-4 rounded-md'
                    onClick={() => handleActionClick(action)}
                  >
                    {action}
                  </button>
                ))}
              </div> */}

              <div className='flex justify-center items-center h-full mt-4'>
                <div className='flex flex-wrap gap-2'>
                  {wfLevelActions && wfLevelActions.map((action, index) => {
                    // Remove any non-alphabet characters
                    const filteredAction = action.replace(/[^a-zA-Z]/g, '');

                    // Only display buttons for "Reject" and "Approve"
                    if (filteredAction === 'Reject' || filteredAction === 'Approve') {
                      return (
                        <button
                          key={index}
                          className={`py-2 px-4 rounded-md ${filteredAction === 'Reject' ? 'bg-red-500' : 'bg-blue-500'} text-white`}
                          onClick={() => handleActionClick(action)}
                        >
                          {filteredAction}
                        </button>
                      );
                    }

                    return null;
                  })}
                </div>
              </div>




              {popupVisible && (
                <div className="fixed inset-0 flex items-center justify-center bg-gray-800 bg-opacity-50 p-4">
                  <div className="bg-white p-4 rounded-lg w-full md:w-1/3">
                    <h2 className="text-xl font-semibold">{selectedAction} Request</h2>
                    <textarea
                      value={actorRemark}
                      onChange={(e) => setActorRemark(e.target.value)}
                      className="w-full h-24 border border-gray-300 mt-2 p-2"
                      placeholder="Add your remarks here"
                    />
                    <div className="flex justify-end mt-4">
                      <button
                        className="bg-blue-500 text-white py-2 px-4 rounded-md"
                        onClick={handleActionConfirmation}
                      >
                        Confirm
                      </button>
                      <button
                        className="bg-gray-500 text-white py-2 px-4 rounded-md ml-2"
                        onClick={handleClosePopup}
                      >
                        Cancel
                      </button>
                    </div>
                  </div>
                </div>
              )}


            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default ManagerApproval;




