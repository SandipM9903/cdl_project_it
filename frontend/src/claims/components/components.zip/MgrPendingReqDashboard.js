import React, { useEffect, useState } from 'react';
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import DataTable from 'react-data-table-component';
import { IoIosLogOut } from 'react-icons/io';
import ManagerApproval from './ManagerApproval';
import { useParams } from 'react-router-dom';
import {useStore3} from './ClaimStore';
import axios from 'axios';
import ManagerAdvApproval from './ManagerAdvApproval';


const MgrPendingReqDashboard = () => {
  
  const {totalClaims, setTotalClaims } = useStore3();
  const {reimbursementRecord, setReimbursementRecord} = useStore3();
  const [selectedRow, setSelectedRow] = useState(null);
  const [showManagerApproval, setShowManagerApproval] = useState(false);
  const {advTotalClaims, setAdvTotalClaims } = useStore3();
  const {advReimbursementRecord, setAdvReimbursementRecord} = useStore3();
  const [showAdvanceApproval, setShowAdvanceApproval] = useState(false);
  const { requestType } = useParams();
 // const empId = sessionStorage.getItem("UserId");
  const empId = 2;
  // console.log("myapproval reimburement rec =>>", reimbursementRecord);

  const tabIndexMapping = {

    'Appraisal Request': 0,

    'Reimbursement Request': 1,

    'Advance Reimbursement Request': 2,

    'Leave Request': 3,

    'Exit Request': 4,

  };

  const defaultIndex = tabIndexMapping[requestType] !== undefined ? tabIndexMapping[requestType] : 0;
  const [value, setValue] = useState(defaultIndex);

  console.log(reimbursementRecord,"reimbursementRecord...");

  useEffect(()=>{
    setTotalClaims(reimbursementRecord.length)
  },[reimbursementRecord])

  console.log(reimbursementRecord,"new reimbursementRecord... ");


  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  
  const openManagerApproval = (row) => {

    setSelectedRow(row);

    setShowManagerApproval(true);

  };



  const closeManagerApproval = () => {

    setShowManagerApproval(false);

    setSelectedRow(null);

  };



  const openAdvanceApproval = (row) => {

    setSelectedRow(row);

    setShowAdvanceApproval(true);

  };



  const closeAdvanceApproval = () => {

    setShowAdvanceApproval(false);

    setSelectedRow(null);

  };

  
  useEffect(() => {
    if (!reimbursementRecord || reimbursementRecord.length === 0) {
    const fetchData = async () => {
      try {
        const [travelResponse, foodResponse, conveyanceResponse, mobileResponse, miscellaneousResponse] = await Promise.all([
         
          axios.get(`http://localhost:9001/api/claims/getFoodClaimPendingList/${empId}`),
          axios.get(`http://localhost:9001/api/claims/getTravelClaimPendingList/${empId}`),
          axios.get(`http://localhost:9001/api/claims/getConveyanceClaimPendingList/${empId}`),
          axios.get(`http://localhost:9001/api/claims/getMobileClaimPendingList/${empId}`),
          axios.get(`http://localhost:9001/api/claims/getMiscellaneousClaimPendingList/${empId}`),
        ]);

       
        const travelClaims = travelResponse.data.filter(claim => claim !== null);
      const foodClaims = foodResponse.data.filter(claim => claim !== null);
      const conveyanceClaims = conveyanceResponse.data.filter(claim => claim !== null);
      const mobileClaims = mobileResponse.data.filter(claim => claim !== null);
      const miscellaneousClaims = miscellaneousResponse.data.filter(claim => claim !== null);


        const allClaims = [...travelClaims, ...foodClaims, ...conveyanceClaims, ...mobileClaims, ...miscellaneousClaims];
       console.log("Allclaims data>>>>>", allClaims);
         // Extract claimUserId from allClaims
    const claimUserIds = allClaims.map(claim => claim.empId);
   // const claimUserIds = [...new Set(allClaims.map(claim => claim.empId))];
   console.log("claim user id===",claimUserIds)
        const empInfoPromises = claimUserIds.map(claimUserId =>
          axios.get(`http://localhost:9001/api/claims/getEmpClaimInfo/${claimUserId}`)
        );

        const empInfoResponses = await Promise.all(empInfoPromises);
        const empInfoData = empInfoResponses.map(response => {
          const{wbsId, ...rest} = response.data[0];
          return rest;
        });


        const mergedData = allClaims.map((claim, index) => ({
          ...claim,
          ...empInfoData[index],
        }));
       console.log("all claims data===",allClaims);
        console.log("merged data===", empInfoData)
        const listInfo = mergedData.map(({ id, ...rest }) => rest);
        setReimbursementRecord(listInfo);

        // Update the totalClaims state
        setTotalClaims(listInfo.length);
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };

    fetchData();
  }
  }, [setTotalClaims, setReimbursementRecord]);

// for advance reimbursement

useEffect(() => {

  if (!advReimbursementRecord || advReimbursementRecord.length === 0) {

  const fetchData = async () => {

    try {

      const [rtaResponse, iouResponse] = await Promise.all([

        axios.get(`http://localhost:9001/api/claims/getRtaClaimPendingList/${empId}`),

        axios.get(`http://localhost:9001/api/claims/getIouClaimPendingList/${empId}`),

      ]);



      const rtaClaims = rtaResponse.data.filter(claim => claim !== null);

      const iouClaims = iouResponse.data.filter(claim => claim !== null);

      

      const allClaims = [...rtaClaims, ...iouClaims];

      const claimUserIds = allClaims.map(claim => claim.empId);
      console.log("claim user id==="+claimUserIds)

      const empInfoPromises = claimUserIds.map(claimUserId =>

        axios.get(`http://localhost:9001/api/claims/getEmpClaimInfo/${claimUserId}`)

      );



      const empInfoResponses = await Promise.all(empInfoPromises);

      // const empInfoData = empInfoResponses.map(response => response.data[0]);

      const empInfoData = empInfoResponses.map(response => {

        const { wbsId, ...rest } = response.data[0]; // Exclude wbsId

        return rest;

      });



      const mergedData = allClaims.map((claim, index) => ({

        ...claim,

        ...empInfoData[index],

      }));



      const listInfo = mergedData.map(({ id, ...rest }) => rest);

      setAdvReimbursementRecord(listInfo);



      // Update the totalClaims state

      setAdvTotalClaims(allClaims.length);

    } catch (error) {

      console.error('Error fetching data:', error);

    }

  };



  fetchData();

}

}, [setAdvTotalClaims, setAdvReimbursementRecord]);
  


  const cols = [
    {
      name: <div className='text-lg font-medium text-black ml-16'>Request</div>,
      cell: (row) => (
        <div className='flex mb-2 hover:cursor-pointer mt-4'>
          <div>
            <div className='ml-12'>
              <h3 className='text-base text-gray-800 -ml-8'>{row.empResDTO.firstName}-{row.empId}
                <span className='text-gray-500 text-sm px-1'>has created the</span>
                {row.claimType}
              </h3>
              <h3 className='text-sm text-gray-500 -ml-8'>{row.empResDTO.mainDeptResDTO.mainDepartment}</h3>
            </div>
          </div>
        </div>
      ),
    },
    {
      name: <div className='text-lg font-medium text-black ml-4'>Requested On</div>,
      center: "true",
      selector: (row) => (
        <div className='text-sm ml-2'>
          <span className='text-gray-500'>{row.createdDate}</span>
        </div>
      ),
    },
    {
      name: <div className='text-lg font-medium text-black ml-4'>Due in Days</div>,
      center: "true",
      cell: (row) => {
        const requestedDate = new Date(row.createdDate);
        const currentDate = new Date();
        const timeDiff = Math.abs(currentDate.getTime() - requestedDate.getTime());
        const diffDays = Math.ceil(timeDiff / (1000 * 3600 * 24));
        return (
          <div className='text-sm ml-2'>
            <span className='text-gray-500'>Due in {diffDays} Days</span>
          </div>
        );
      },
    },
    {
      name: <div className='text-lg font-medium text-black ml-4'></div>,
      selector: (row) => (
        <div>
          <div className='text-lg ml-4'>
          <button className='text-blue-400' onClick={() => openManagerApproval(row)}><IoIosLogOut /></button>

</div>

</div>

),

},

];



const advCols = [

{

name: <div className='text-lg font-medium text-black ml-16'>Request</div>,

cell: (row) => (

<div className='flex mb-2 hover:cursor-pointer mt-4'>

<div>

  <div className='ml-12'>

    <h3 className='text-base text-gray-800 -ml-8'>{row.empResDTO.firstName}-{row.empId}

      <span className='text-gray-500 text-sm px-1'>has created the</span>

      {row.claimType}

    </h3>

    <h3 className='text-sm text-gray-500 -ml-8'>{row.empResDTO.mainDeptResDTO.mainDepartment}</h3>

  </div>

</div>

</div>

),

},

{

name: <div className='text-lg font-medium text-black ml-4'>Requested On</div>,

center: "true",

selector: (row) => (

<div className='text-sm ml-2'>

<span className='text-gray-500'>{row.createdDate}</span>

</div>

),

},

{

name: <div className='text-lg font-medium text-black ml-4'>Due in Days</div>,

center: "true",

cell: (row) => {

const requestedDate = new Date(row.createdDate);

const currentDate = new Date();

const timeDiff = Math.abs(currentDate.getTime() - requestedDate.getTime());

const diffDays = Math.ceil(timeDiff / (1000 * 3600 * 24));

return (

<div className='text-sm ml-2'>

  <span className='text-gray-500'>Due in {diffDays} Days</span>

</div>

);

},

},

{

name: <div className='text-lg font-medium text-black ml-4'></div>,

selector: (row) => (

<div>

<div className='text-lg ml-4'>

  <button className='text-blue-400' onClick={() => openAdvanceApproval(row)}><IoIosLogOut /></button>

</div>

</div>

),

},

];

  return (
    <div>
      <Tabs value={value} onChange={handleChange}>
        <Tab label="Appraisal Request" />
        <Tab label={
          <div>
            Reimbursement Request
            <span className='ml-2 bg-blue-500 text-white rounded-full px-2 py-1'>
              {totalClaims}
            </span>
          </div>
        } />
        <Tab label={

<div>

  Advance Reimbursement Request

  <span className='ml-2 bg-blue-500 text-white rounded-full px-2 py-1'>

    {advTotalClaims}

  </span>

</div>

} />
        <Tab label="Leave Request" />
        <Tab label="Exit Request" />
      </Tabs>

      {value === 0 && <h2>Appraisal Request Content</h2>}
      {value === 1 && (
        <>
          <DataTable columns={cols} data={reimbursementRecord} />
          {showManagerApproval && selectedRow && (
            <ManagerApproval 
              rowData={selectedRow} 
              onClose={closeManagerApproval} 
              // reimbursementRecord={reimbursementRecord} 
              // setReimbursementRecord={setReimbursementRecord}
            />
          )}
        </>
      )}
       {value === 2 && (

<>

  <DataTable columns={advCols} data={advReimbursementRecord} />

  {showAdvanceApproval && selectedRow && (

    <ManagerAdvApproval 

      rowData={selectedRow} 

      onClose={closeAdvanceApproval} 

      // advReimbursementRecord={advReimbursementRecord} 

      // setAdvReimbursementRecord={setAdvReimbursementRecord}

    />

  )}

</>

)}
      {value === 3 && <h2>Leave Request Content</h2>}
      {value === 4 && <h2>Exit Request Content</h2>}
    </div>
  );
};

export default MgrPendingReqDashboard;

