import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { IoIosLogOut } from 'react-icons/io';
import { useStore3 } from './ClaimStore';
import axios from 'axios';

const MgrPendingReqHomePage = () => {
  const navigate = useNavigate();
  const [pendingCounts, setPendingCounts] = useState({
    travel: 0,
    food: 0,
    conveyance: 0,
    mobile: 0,
    miscellaneous: 0
  });

  const handleNavigation = (requestType) => {
    navigate(`/approvals/${requestType}`);
  };

  const { totalClaims, setTotalClaims } = useStore3();
  const { reimbursementRecord, setReimbursementRecord } = useStore3();
  const { advTotalClaims, setAdvTotalClaims } = useStore3();
  const { advReimbursementRecord, setAdvReimbursementRecord } = useStore3();
  const [ pendingClaims, setPendingClaims ] = useState(0);
  console.log("reimbursementRecord>>>>", reimbursementRecord);
  //const empId = sessionStorage.getItem("UserId");
  const empId = 2;
  useEffect(() => {
    const fetchData = async () => {
      try {
        const [travelResponse, foodResponse, conveyanceResponse, mobileResponse, miscellaneousResponse] = await Promise.all([
          axios.get(`http://localhost:9001/api/claims/getFoodClaimPendingList/${empId}`),
          axios.get(`http://localhost:9001/api/claims/getTravelClaimPendingList/${empId}`),
          axios.get(`http://localhost:9001/api/claims/getConveyanceClaimPendingList/${empId}`),
          axios.get(`http://localhost:9001/api/claims/getMobileClaimPendingList/${empId}`),
          axios.get(`http://localhost:9001/api/claims/getMiscellaneousClaimPendingList/${empId}`),
        ]);

        const travelClaims = travelResponse.data.filter(claim => claim !== null);
      const foodClaims = foodResponse.data.filter(claim => claim !== null);
      const conveyanceClaims = conveyanceResponse.data.filter(claim => claim !== null);
      const mobileClaims = mobileResponse.data.filter(claim => claim !== null);
      const miscellaneousClaims = miscellaneousResponse.data.filter(claim => claim !== null);


        const allClaims = [...travelClaims, ...foodClaims, ...conveyanceClaims, ...mobileClaims, ...miscellaneousClaims];
       

        const claimUserIds = allClaims.map(claim => claim.empId);
        const empInfoPromises = claimUserIds.map(claimUserIds =>
          axios.get(`http://localhost:9001/api/claims/getEmpClaimInfo/${claimUserIds}`)
        );

        const empInfoResponses = await Promise.all(empInfoPromises);
        // const empInfoData = empInfoResponses.map(response => response.data[0]);
        const empInfoData = empInfoResponses.map(response => {
          const { wbsId, ...rest } = response.data[0]; // Exclude wbsId
          return rest;
        });
        
        const mergedData = allClaims.map((claim, index) => ({
          ...claim,
          ...empInfoData[index],
        }));

        const listInfo = mergedData.map(({ id, ...rest }) => rest);
        setReimbursementRecord(listInfo);

        
    
        // Calculate the number of pending claims for each category
        setPendingCounts({
          travel: travelClaims.length,
          food: foodClaims.length,
          conveyance: conveyanceClaims.length,
          mobile: mobileClaims.length,
          miscellaneous: miscellaneousClaims.length
        });

        // Update the totalClaims state
        setTotalClaims(allClaims.length);
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };

    fetchData();
  }, [setTotalClaims, setReimbursementRecord]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [rtaResponse, iouResponse] = await Promise.all([
          axios.get(`http://localhost:9001/api/claims/getRtaClaimPendingList/${empId}`),

        axios.get(`http://localhost:9001/api/claims/getIouClaimPendingList/${empId}`),
        ]);

        const rtaClaims = rtaResponse.data.filter(claim => claim !== null);
        ;
        const iouClaims = iouResponse.data.filter(claim => claim !== null);
        ;
        
        const allClaims = [...rtaClaims, ...iouClaims];
        
        const claimUserIds = allClaims.map(claim => claim.empId);
        const empInfoPromises = claimUserIds.map(claimUserIds =>
          axios.get(`http://localhost:9001/api/claims/getEmpClaimInfo/${claimUserIds}`)
        );

        const empInfoResponses = await Promise.all(empInfoPromises);
        // const empInfoData = empInfoResponses.map(response => response.data[0]);
        const empInfoData = empInfoResponses.map(response => {
          const { wbsId, ...rest } = response.data[0]; // Exclude wbsId
          return rest;
        });
        
        const mergedData = allClaims.map((claim, index) => ({
          ...claim,
          ...empInfoData[index],
        }));

        const listInfo = mergedData.map(({ id, ...rest }) => rest);
        setAdvReimbursementRecord(listInfo);

        // Update the totalClaims state
        setAdvTotalClaims(allClaims.length);
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };

    fetchData();
  }, [setAdvTotalClaims, setAdvReimbursementRecord]);


 useEffect(()=>{
   setPendingClaims(totalClaims + advTotalClaims);
 }, [totalClaims, advTotalClaims])

  return (
    <div>
    <div className='bg-gray-200 h-screen w-full'>
      <div className='bg-white h-[270px] w-[550px] rounded-lg ml-8 mt-4 absolute overflow-y-auto'>
        <div className='p-4'>
          <div className='grid grid-cols-8'>
            <div className='col-span-4 space-y-7'>
              <h1 className='font-semibold mb-4'>Request For Approval</h1>
              <div className='text-sm ml-2'>Appraisal Request</div>
              <div className='text-sm ml-2'>Reimbursement Request</div>
              <div className='text-sm ml-2'>Advance Reimbursement Request</div>
              <div className='text-sm ml-2'>Leave Request</div>
              <div className='text-sm ml-2'>Exit Request</div>
            </div>
            <div className='col-span-2 space-y-7'>
              <div className='flex gap-2 mb-5'>
                <h1 className='font-semibold'>Pending</h1>
                <div className='bg-red-500 text-white rounded-lg w-10 text-center font-semibold'>{pendingClaims}</div>
              </div>
              <div className='flex justify-center h-5 w-5 rounded-full bg-blue-400 text-white text-sm ml-20'>0</div>
              <div className='flex justify-center h-5 w-5 rounded-full bg-blue-400 text-white text-sm ml-20'>{totalClaims}</div>
              <div className='flex justify-center h-5 w-5 rounded-full bg-blue-400 text-white text-sm ml-20'>{advTotalClaims}</div>
              <div className='flex justify-center h-5 w-5 rounded-full bg-blue-400 text-white text-sm ml-20'>0</div>
              <div className='flex justify-center h-5 w-5 rounded-full bg-blue-400 text-white text-sm ml-20'>0</div>
            </div>
            <div className='col-span-2 space-y-[23px]'>
              <button className='float-end -mt-4 text-xs text-blue-500'>View All</button>
              <button className='text-xl pt-[26px] ml-20 text-blue-600' onClick={() => handleNavigation('Appraisal Request')}><IoIosLogOut /></button>
              <button className='text-xl ml-20 text-blue-600' onClick={() => handleNavigation('Reimbursement Request')}><IoIosLogOut /></button>
              <button className='text-xl ml-20 text-blue-600' onClick={() => handleNavigation('Advance Reimbursement Request')}><IoIosLogOut /></button>
              <button className='text-xl ml-20 text-blue-600' onClick={() => handleNavigation('Leave Request')}><IoIosLogOut /></button>
              <button className='text-xl ml-20 text-blue-600' onClick={() => handleNavigation('Exit Request')}><IoIosLogOut /></button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
);
};

export default MgrPendingReqHomePage;


