import axios from 'axios';
import React, { useEffect, useState } from 'react';

function Salary_Account_Details() {
    const [empSalaryAccountDetails, setEmpSalaryAccountDetails] = useState({});
    const [empData, setEmpData] = useState({});
    const [userData, setUserData] = useState({});
    const [isEditing, setIsEditing] = useState(false); // State to manage edit mode

    const email = localStorage.getItem('email');

    useEffect(() => {
        axios
            .get(`http://43.205.24.208:9020/employee/by/email/${email}`)
            .then((response) => {
                setEmpData(response.data.fileAndObjectTypeBean.empResDTO);
                setUserData(response.data.userDTO);
            })
            .catch(error => console.error('Error fetching data:', error));
    }, [email]);

    const handleEditToggle = () => {
        setIsEditing(!isEditing);
    };

    const handleChange = (e) => {
        setEmpSalaryAccountDetails({
            ...empSalaryAccountDetails,
            [e.target.name]: e.target.value,
        });
    };

    const handleSave = () => {
        // Implement the save functionality here
        // You would typically make an API call to save the updated data
        console.log('Updated Salary Account Details:', empSalaryAccountDetails);
        setIsEditing(false); // Exit edit mode
    };

    return (
        <div>
            <div className='bg-white border-[2px] border-gray-200 shadow-lg w-[380px] rounded-lg py-3 px-4 relative'>
                <h4 className='font-semibold mb-1.5 text-sm'>Salary Account Details</h4>
                <button 
                    onClick={handleEditToggle} 
                    className='absolute top-3 right-3 text-xs text-blue-500 underline'>
                    {isEditing ? 'Save' : 'Edit'}
                </button>

                <div className='grid grid-cols-2 border-b-[1px] border-gray-200 py-1.5 text-xs'>
                    <div className='text-gray-500'>Salary Account Bank Name</div>
                    {isEditing ? (
                        <input
                            type='text'
                            name='bankName'
                            value={empSalaryAccountDetails.bankName || empData.salaryAccDetailsResDTO?.bankName}
                            onChange={handleChange}
                            className='ml-2 border border-gray-300 rounded px-1'
                        />
                    ) : (
                        <div className='ml-2'>{empData.salaryAccDetailsResDTO?.bankName}</div>
                    )}
                </div>

                <div className='grid grid-cols-2 border-b-[1px] border-gray-200 py-1.5 text-xs'>
                    <div className='text-gray-500'>Salary Account Number</div>
                    {isEditing ? (
                        <input
                            type='text'
                            name='accountNumber'
                            value={empSalaryAccountDetails.accountNumber || empData.salaryAccDetailsResDTO?.accountNumber}
                            onChange={handleChange}
                            className='ml-2 border border-gray-300 rounded px-1'
                        />
                    ) : (
                        <div className='ml-2'>{empData.salaryAccDetailsResDTO?.accountNumber}</div>
                    )}
                </div>

                <div className='grid grid-cols-2 border-b-[1px] border-gray-200 py-1.5 text-xs'>
                    <div className='text-gray-500'>Name as per salary account</div>
                    {isEditing ? (
                        <input
                            type='text'
                            name='nameOnAccount'
                            value={empSalaryAccountDetails.nameOnAccount || empData.salaryAccDetailsResDTO?.nameOnAccount}
                            onChange={handleChange}
                            className='ml-2 border border-gray-300 rounded px-1'
                        />
                    ) : (
                        <div className='ml-2'>{empData.salaryAccDetailsResDTO?.nameOnAccount}</div>
                    )}
                </div>

                <div className='grid grid-cols-2 py-1.5 text-xs'>
                    <div className='text-gray-500'>Salary Account IFSC</div>
                    {isEditing ? (
                        <input
                            type='text'
                            name='ifsc'
                            value={empSalaryAccountDetails.ifsc || empData.salaryAccDetailsResDTO?.ifsc}
                            onChange={handleChange}
                            className='ml-2 border border-gray-300 rounded px-1'
                        />
                    ) : (
                        <div className='ml-2'>{empData.salaryAccDetailsResDTO?.ifsc}</div>
                    )}
                </div>
            </div>
        </div>
    );
}

export default Salary_Account_Details;
