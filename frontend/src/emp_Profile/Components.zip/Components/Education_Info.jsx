import axios from 'axios';
import React, { useEffect, useState } from 'react';
import DataTable from 'react-data-table-component';
import { FaDownload, FaEye } from 'react-icons/fa';
import { saveAs } from 'file-saver';
import { useNavigate } from 'react-router-dom';

function Education_Info() {
    const [empEducationInfo, setEmpEducationInfo] = useState([]);
    const [empData, setEmpData] = useState({});
    const [userData, setUserData] = useState({});
    const [fileUrl, setFileUrl] = useState('');
    const [isEditing, setIsEditing] = useState(false); // State for editing mode

    const navigate = useNavigate('');
    const email = localStorage.getItem('email');
  
    useEffect(() => {
        axios
        .get(`http://43.205.24.208:9020/employee/by/email/${email}`)
        .then((response) => {
            setEmpData(response.data.fileAndObjectTypeBean.empResDTO);
            setUserData(response.data.userDTO);
        })
        .catch((error) => {
            alert(error);
        });
    }, []);

    const handleEditClick = () => {
        setIsEditing(!isEditing); // Toggle editing mode
    };

    const handleInputChange = (index, field, value) => {
        const updatedEducationData = [...userData.educationResDTOS];
        updatedEducationData[index][field] = value; // Update the specific field
        setUserData({ ...userData, educationResDTOS: updatedEducationData });
    };

    const column = [
        {
            name: "Institute Name",
            selector: row => isEditing ? (
                <input 
                    type="text" 
                    value={row.instituteName} 
                    onChange={(e) => handleInputChange(userData.educationResDTOS.indexOf(row), 'instituteName', e.target.value)}
                />
            ) : row.instituteName,
        },
        {
            name: "Field of Study",
            selector: row => isEditing ? (
                <input 
                    type="text" 
                    value={row.fieldOfStudy} 
                    onChange={(e) => handleInputChange(userData.educationResDTOS.indexOf(row), 'fieldOfStudy', e.target.value)}
                />
            ) : row.fieldOfStudy,
        },
        {
            name: "Qualification",
            selector: row => isEditing ? (
                <input 
                    type="text" 
                    value={row.qualification} 
                    onChange={(e) => handleInputChange(userData.educationResDTOS.indexOf(row), 'qualification', e.target.value)}
                />
            ) : row.qualification,
        },
        {
            name: "Certificate",
            selector: row => isEditing ? (
                <input 
                    type="text" 
                    value={row.certificate} 
                    onChange={(e) => handleInputChange(userData.educationResDTOS.indexOf(row), 'certificate', e.target.value)}
                />
            ) : row.certificate,
        },
        {
            name: "Document Name",
            selector: row => isEditing ? (
                <input 
                    type="text" 
                    value={row.docName} 
                    onChange={(e) => handleInputChange(userData.educationResDTOS.indexOf(row), 'docName', e.target.value)}
                />
            ) : row.docName,
        },
        {
            name: "Document ID",
            selector: row => isEditing ? (
                <input 
                    type="text" 
                    value={row.educationDocId} 
                    onChange={(e) => handleInputChange(userData.educationResDTOS.indexOf(row), 'educationDocId', e.target.value)}
                />
            ) : row.educationDocId,
        },
    ];

    const newStyle = {
        headCells: {
            style: {
                fontWeight: "normal",
                fontSize: "13px",
                height: "36px",
                paddingRight: "8px",
                maxWidth: '100%',
                zIndex: 100,
            },
        },
        cells: {
            style: {
                fontWeight: "normal",
                fontSize: "13px",
                paddingRight: "8px",
                color: "#55565B",
                maxWidth: '100%',
                zIndex: 100
            },
        },
    };

    const handleDownload = (documentId, empId, documentName) => {
        axios.get(`http://localhost:8080/employee/download/education/document/${documentId}`, { responseType: 'arraybuffer' })
        .then(res => {
            const contentType = res.headers['content-type'];
            const blob = new Blob([res.data], { type: contentType });
            saveAs(blob, empId + "-" + documentName);
        }).catch(err => {
            alert(err);
        });
    };

    const openDocument = (docId) => {
        navigate(`doc-viewer/${docId}`);
    };

    return (
        <div>
            <div className='bg-white border-[2px] border-gray-200 shadow-lg w-[1220px] rounded-lg py-3 px-4'>
                <div className="flex justify-between items-center">
                    <h4 className='font-semibold mb-1.5 text-sm'>Education</h4>
                    <button 
                        className="text-blue-500 underline" 
                        onClick={handleEditClick}
                    >
                        {isEditing ? 'Save' : 'Edit'}
                    </button>
                </div>
                <DataTable 
                    columns={column} 
                    data={userData.educationResDTOS}
                    customStyles={newStyle}
                />
            </div>
        </div>
    );
}

export default Education_Info;
