import axios from 'axios';
import React, { useEffect, useState } from 'react';

function Personal_Info() {
    const [empData, setEmpData] = useState({});
    const [userData, setUserData] = useState({});
    const [isEditable, setIsEditable] = useState(false); // To toggle edit mode
    const email = localStorage.getItem('email');
  
    useEffect(() => {
      axios
      .get(`http://43.205.24.208:9020/employee/by/email/${email}`)
      .then((response) => {
          setEmpData(response.data.fileAndObjectTypeBean.empResDTO);
          setUserData(response.data.userDTO);
        })
        .catch(error => console.error('Error fetching data:', error));
    }, [email]);

    // Function to handle the edit/save button click
    const handleEditClick = () => {
        setIsEditable(!isEditable);
    };

    // Function to handle saving the updated data (You can customize it to save data to the backend)
    const handleSave = () => {
        // Logic to save updated data
        console.log('Data saved:', { empData, userData });
        setIsEditable(false); // Exit edit mode
    };

    // Function to handle input changes for editable fields
    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setEmpData({ ...empData, [name]: value });
    };

    return (
        <div className='bg-white border-[2px] border-gray-200 shadow-lg w-[380px] rounded-lg py-3 px-4'>
          <div className="flex justify-between items-center">
            <h4 className='font-semibold mb-1.5 text-sm'>Personal</h4>
            <button
              className='text-blue-500 text-sm'
              onClick={isEditable ? handleSave : handleEditClick}
            >
              {isEditable ? 'Save' : 'Edit'}
            </button>
          </div>

          <div className='grid grid-cols-2 border-b-[1px] border-gray-200 py-1.5 text-xs'>
            <div className='text-gray-500'>Primary Contact Number</div>
            <div className='ml-4 overflow-hidden text-ellipsis'>
              {isEditable ? (
                <input 
                  type="text" 
                  name="primaryContactNo" 
                  value={empData.primaryContactNo || ''} 
                  onChange={handleInputChange} 
                  className="border-b-[1px] border-gray-300"
                />
              ) : (
                empData.primaryContactNo
              )}
            </div>
          </div>

          <div className='grid grid-cols-2 border-b-[1px] border-gray-200 py-1.5 text-xs'>
            <div className='text-gray-500'>Secondary Contact Number</div>
            <div className='ml-4 overflow-hidden text-ellipsis'>
              {isEditable ? (
                <input 
                  type="text" 
                  name="secondaryContactNo" 
                  value={empData.secondaryContactNo || ''} 
                  onChange={handleInputChange} 
                  className="border-b-[1px] border-gray-300"
                />
              ) : (
                empData.secondaryContactNo
              )}
            </div>
          </div>

          <div className='grid grid-cols-2 border-b-[1px] border-gray-200 py-1.5 text-xs'>
            <div className='text-gray-500'>Date of Birth</div>
            <div className='ml-4'>
              {isEditable ? (
                <input 
                  type="text" 
                  name="dateOfBirth" 
                  value={empData.dateOfBirth || ''} 
                  onChange={handleInputChange} 
                  className="border-b-[1px] border-gray-300"
                />
              ) : (
                empData.dateOfBirth
              )}
            </div>
          </div>

          <div className='grid grid-cols-2 border-b-[1px] border-gray-200 py-1.5 text-xs'>
            <div className='text-gray-500'>Gender</div>
            <div className='ml-4'>
              {isEditable ? (
                <input 
                  type="text" 
                  name="gender" 
                  value={empData.gender || ''} 
                  onChange={handleInputChange} 
                  className="border-b-[1px] border-gray-300"
                />
              ) : (
                empData.gender
              )}
            </div>
          </div>

          <div className='grid grid-cols-2 border-b-[1px] border-gray-200 py-1.5 text-xs'>
            <div className='text-gray-500'>Blood Group</div>
            <div className='ml-4'>
              {isEditable ? (
                <input 
                  type="text" 
                  name="bloodGroup" 
                  value={empData.bloodGroup || ''} 
                  onChange={handleInputChange} 
                  className="border-b-[1px] border-gray-300"
                />
              ) : (
                empData.bloodGroup
              )}
            </div>
          </div>

          <div className='grid grid-cols-2 border-b-[1px] border-gray-200 py-1.5 text-xs'>
            <div className='text-gray-500'>Emergency Contact</div>
            <div className='ml-4 overflow-hidden text-ellipsis'>
              {isEditable ? (
                <input 
                  type="text" 
                  name="emergencyContactNo" 
                  value={empData.emergencyContactNo || ''} 
                  onChange={handleInputChange} 
                  className="border-b-[1px] border-gray-300"
                />
              ) : (
                empData.emergencyContactNo
              )}
            </div>
          </div>

          <div className='grid grid-cols-2 border-b-[1px] border-gray-200 py-1.5 text-xs'>
            <div className='text-gray-500'>Emergency Contact Name</div>
            <div className='ml-4 overflow-hidden text-ellipsis'>
              {isEditable ? (
                <input 
                  type="text" 
                  name="emergencyContactName" 
                  value={empData.emergencyContactName || ''} 
                  onChange={handleInputChange} 
                  className="border-b-[1px] border-gray-300"
                />
              ) : (
                empData.emergencyContactName
              )}
            </div>
          </div>

          <div className='grid grid-cols-2 border-b-[1px] border-gray-200 py-1.5 text-xs'>
            <div className='text-gray-500'>Relationship with Emergency Contact</div>
            <div className='ml-4 overflow-hidden text-ellipsis'>
              {isEditable ? (
                <input 
                  type="text" 
                  name="relationWithEmergencyContact" 
                  value={empData.relationWithEmergencyContact || ''} 
                  onChange={handleInputChange} 
                  className="border-b-[1px] border-gray-300"
                />
              ) : (
                empData.relationWithEmergencyContact
              )}
            </div>
          </div>

          <div className='grid grid-cols-2 border-b-[1px] border-gray-200 py-1.5 text-xs'>
            <div className='text-gray-500'>Personal Email</div>
            <div className='ml-4 overflow-hidden text-ellipsis'>
              {isEditable ? (
                <input 
                  type="text" 
                  name="email" 
                  value={userData.email || ''} 
                  onChange={(e) => setUserData({ ...userData, email: e.target.value })}
                  className="border-b-[1px] border-gray-300"
                />
              ) : (
                userData.email
              )}
            </div>
          </div>

          <div className='grid grid-cols-2 border-b-[1px] border-gray-200 py-1.5 text-xs'>
            <div className='text-gray-500'>Passport Number</div>
            <div className='ml-4 overflow-hidden text-ellipsis'>
              {isEditable ? (
                <input 
                  type="text" 
                  name="passportNumber" 
                  value={empData.passportNumber || ''} 
                  onChange={handleInputChange} 
                  className="border-b-[1px] border-gray-300"
                />
              ) : (
                empData.passportNumber
              )}
            </div>
          </div>

          <div className='grid grid-cols-2 border-b-[1px] border-gray-200 py-1.5 text-xs'>
            <div className='text-gray-500'>Age</div>
            <div className='ml-4'>
              {isEditable ? (
                <input 
                  type="text" 
                  name="age" 
                  value={empData.age || ''} 
                  onChange={handleInputChange} 
                  className="border-b-[1px] border-gray-300"
                />
              ) : (
                empData.age
              )}
            </div>
          </div>

          <div className='grid grid-cols-2 border-b-[1px] border-gray-200 py-1.5 text-xs'>
            <div className='text-gray-500'>Marital Status</div>
            <div className='ml-4'>
              {isEditable ? (
                <select
                  name="maritalStatus"
                  value={empData.maritalStatus || ''}
                  onChange={handleInputChange}
                  className="border-b-[1px] border-gray-300"
                >
                  <option value="Married">Married</option>
                  <option value="Unmarried">Unmarried</option>
                  <option value="Widowed">Widowed</option>
                  <option value="Single">Single</option>
                </select>
              ) : (
                empData.maritalStatus
              )}
            </div>
          </div>
        </div>
    );
}

export default Personal_Info;
