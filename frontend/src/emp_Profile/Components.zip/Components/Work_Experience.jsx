import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { FaDownload, FaEye } from 'react-icons/fa';
import { saveAs } from 'file-saver';
import { useNavigate } from 'react-router-dom';
import DataTable from 'react-data-table-component';

function Work_Experience() {
    const [empWorkExperience, setEmpWorkExperience] = useState([]);
    const navigate = useNavigate('');
    const [empData, setEmpData] = useState({});
    const [userData, setUserData] = useState({});
    const [isEditing, setIsEditing] = useState(false); // Editing state

    const email = localStorage.getItem('email');
  
    useEffect(() => {
        axios
        .get(`http://43.205.24.208:9020/employee/by/email/${email}`)
        .then((response) => {
            setEmpData(response.data.fileAndObjectTypeBean.empResDTO);
            setUserData(response.data.userDTO);
        })
        .catch((error) => {
            console.log("Error fetching data:", error);
        });
    }, []);

    const handleEditClick = () => {
        setIsEditing(!isEditing); // Toggle editing mode
    };

    const handleInputChange = (index, field, value) => {
        const updatedWorkExperience = [...userData.experienceResDTOS];
        updatedWorkExperience[index][field] = value; // Update specific field
        setUserData({ ...userData, experienceResDTOS: updatedWorkExperience });
    };

    const column = [
        {
            name: "Company Name",
            selector: row => isEditing ? (
                <input 
                    type="text" 
                    value={row.companyName} 
                    onChange={(e) => handleInputChange(userData.experienceResDTOS.indexOf(row), 'companyName', e.target.value)}
                />
            ) : row.companyName,
            wrap: true,
        },
        {
            name: "Job Title",
            selector: row => isEditing ? (
                <input 
                    type="text" 
                    value={row.jobTitle} 
                    onChange={(e) => handleInputChange(userData.experienceResDTOS.indexOf(row), 'jobTitle', e.target.value)}
                />
            ) : row.jobTitle,
            wrap: true,
        },
        {
            name: "Experience",
            selector: row => isEditing ? (
                <input 
                    type="text" 
                    value={row.experience} 
                    onChange={(e) => handleInputChange(userData.experienceResDTOS.indexOf(row), 'experience', e.target.value)}
                />
            ) : row.experience,
            wrap: true,
        },
        {
            name: "From Date",
            selector: row => isEditing ? (
                <input 
                    type="date" 
                    value={row.dateOfJoining} 
                    onChange={(e) => handleInputChange(userData.experienceResDTOS.indexOf(row), 'dateOfJoining', e.target.value)}
                />
            ) : row.dateOfJoining,
        },
        {
            name: "To Date",
            selector: row => isEditing ? (
                <input 
                    type="date" 
                    value={row.dateOfReliving} 
                    onChange={(e) => handleInputChange(userData.experienceResDTOS.indexOf(row), 'dateOfReliving', e.target.value)}
                />
            ) : row.dateOfReliving,
        },
        {
            name: "Certification",
            selector: row => isEditing ? (
                <input 
                    type="text" 
                    value={row.certification} 
                    onChange={(e) => handleInputChange(userData.experienceResDTOS.indexOf(row), 'certification', e.target.value)}
                />
            ) : row.certification,
            wrap: true,
        },
    ];
    

    const newStyle = {
        headCells: {
            style: {
                fontWeight: "normal",
                fontSize: "13px",
                height: "36px",
                paddingRight: "6px",
                maxWidth: "100%",
            },
        },
        cells: {
            style: {
                fontWeight: "normal",
                fontSize: "13px",
                paddingRight: "6px",
                color: "#55565B",
                maxWidth: "100%",
            },
        },
    };

    const handleDownload = (documentId, empId, documentName) => {
        axios.get(`http://localhost:8080/employee/download/education/document/${documentId}`, { responseType: 'arraybuffer' })
        .then(res => {
            const contentType = res.headers['content-type'];
            const blob = new Blob([res.data], { type: contentType });
            saveAs(blob, empId + "-" + documentName);
        }).catch(err => {
            alert(err);
        });
    };

    const openDocument = (docId) => {
        navigate(`doc-viewer/${docId}`);
    };

    return (
        <div className='bg-white border-[2px] border-gray-200 shadow-lg w-[1220px] rounded-lg py-3 px-4'>
            <div className="flex justify-between items-center">
                <h4 className='font-semibold mb-1.5 text-sm'>Work Experience</h4>
                <button 
                    className="text-blue-500 underline" 
                    onClick={handleEditClick}
                >
                    {isEditing ? 'Save' : 'Edit'}
                </button>
            </div>
            <DataTable 
                columns={column} 
                data={userData.experienceResDTOS}
                customStyles={newStyle}
            />
        </div>
    );
}

export default Work_Experience;
